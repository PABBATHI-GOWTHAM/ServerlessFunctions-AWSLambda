import json
import requests
from bs4 import BeautifulSoup  # ← Add this import

def lambda_handler(event, context):
    try:
        # Parse the incoming request
        if "body" in event:
            body = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
        else:
            body = event
        
        # Get URL from request
        url = body.get("url")
        if not url:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "URL is required"})
            }
        
        # Your Hugging Face token
        hf_token = "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"
        
        # Fetch article content
        print(f"Fetching article from: {url}")
        article_response = requests.get(url, timeout=10, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        article_response.raise_for_status()
        
        # Extract readable text using BeautifulSoup (THIS IS THE NEW PART)
        soup = BeautifulSoup(article_response.content, "html.parser")
        article_text = soup.get_text(separator=' ', strip=True)
        
        # Optional: Keep only first 2000 characters for summarization (to avoid model limits)
        article_text = article_text[:2000]
        
        # Call Hugging Face API for summarization
        API_URL = "https://api-inference.huggingface.co/models/facebook/bart-large-cnn"
        headers = {"Authorization": f"Bearer {hf_token}"}
        
        payload = {
            "inputs": article_text,
            "parameters": {
                "max_length": 150,
                "min_length": 50,
                "do_sample": False
            }
        }
        
        print("Calling Hugging Face API...")
        hf_response = requests.post(API_URL, headers=headers, json=payload, timeout=30)
        
        if hf_response.status_code == 200:
            result = hf_response.json()
            if isinstance(result, list) and len(result) > 0:
                summary = result[0].get("summary_text", "No summary generated")
            else:
                summary = "Could not generate summary"
        else:
            summary = f"Hugging Face API error: {hf_response.status_code}"
        
        # Return successful response
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "summary": summary,
                "url": url,
                "status": "success"
            })
        }
        
    except requests.exceptions.RequestException as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Network error: {str(e)}"})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Unexpected error: {str(e)}"})
        }
